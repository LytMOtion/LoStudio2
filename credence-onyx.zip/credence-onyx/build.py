import pathlib

ROOT = pathlib.Path("/home/claude/lo2")

# ----- Client data (single source; mirror of README find/replace tokens) -----
C = dict(
    name="Daniel Harper",
    title="Senior Mortgage Advisor",
    company="Coastal Bridge Home Loans",
    nmls="1845627",
    co_nmls="2279431",
    phone="(805) 555-1847",
    tel="+18055551847",
    email="daniel@coastalbridgehl.com",
    addr1="1450 State Street, Suite 210",
    addr2="Santa Barbara, CA 93101",
    cal="https://calendly.com/danielharper/consultation",
    apply="https://apply.coastalbridgehl.com/danielharper",
    prequal="https://prequal.coastalbridgehl.com/danielharper",
    ig="https://instagram.com/danielharpermortgage",
    li="https://linkedin.com/in/danielharpermortgage",
    consumer="https://www.nmlsconsumeraccess.org/",
)

NAV = [
    ("index.html", "Home", "home"),
    ("about.html", "About", "about"),
    ("loan-programs.html", "Loan Programs", "programs"),
    ("realtor-partners.html", "Realtor Partners", "realtors"),
]

def head(title, desc, active, over_dark):
    links = "".join(
        f'<a href="{href}" class="lnk{" active" if k==active else ""}">{label}</a>'
        for href, label, k in NAV
    )
    od = " over-dark" if over_dark else ""
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
<header class="head{od}">
  <div class="wrap head-in">
    <a href="index.html" class="brand">
      <span class="nm">{C['name']}</span>
      <span class="co">{C['company']}</span>
    </a>
    <nav class="nav" aria-label="Primary">
      {links}
      <a href="{C['cal']}" class="head-cta">Schedule</a>
    </nav>
    <button class="burger" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>'''

def foot():
    return f'''<footer class="foot">
  <div class="wrap">
    <div class="foot-top">
      <div>
        <div class="f-nm">{C['name']}</div>
        <div class="f-ti">{C['title']}</div>
        <div class="f-addr">{C['company']}<br>{C['addr1']}<br>{C['addr2']}</div>
        <div class="eh">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M3 11l9-7 9 7"/><path d="M5 10v9h14v-9"/><path d="M9 19v-5h6v5"/></svg>
          Equal Housing Lender
        </div>
      </div>
      <div class="fcol">
        <h4>Contact</h4>
        <a href="tel:{C['tel']}">{C['phone']}</a>
        <a href="mailto:{C['email']}">{C['email']}</a>
        <a href="{C['ig']}">Instagram</a>
        <a href="{C['li']}">LinkedIn</a>
      </div>
      <div class="fcol">
        <h4>Navigate</h4>
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="loan-programs.html">Loan Programs</a>
        <a href="realtor-partners.html">Realtor Partners</a>
      </div>
      <div class="fcol">
        <h4>Licensing</h4>
        <p>Personal NMLS #{C['nmls']}</p>
        <p>Company NMLS #{C['co_nmls']}</p>
        <a href="{C['consumer']}">NMLS Consumer Access</a>
        <p style="margin-top:8px">Licensed in California</p>
      </div>
    </div>
    <div class="foot-legal">
      <p class="disc">All loans are subject to credit approval and program guidelines. This is not a commitment to lend. Rates, terms, and program availability are subject to change without notice.</p>
      <div class="flinks">
        <a href="privacy.html">Privacy Policy</a>
        <a href="terms.html">Terms of Use</a>
        <a href="{C['consumer']}">NMLS Consumer Access</a>
      </div>
    </div>
    <p class="f-copy">© 2026 {C['company']}. All rights reserved. &nbsp;·&nbsp; Onyx — a credencesites.com template.</p>
  </div>
</footer>
<nav class="mbar" aria-label="Quick actions">
  <a href="tel:{C['tel']}">Call</a>
  <a href="{C['cal']}" class="primary">Schedule</a>
  <a href="{C['apply']}">Apply</a>
</nav>
<script src="assets/js/main.js"></script>
</body>
</html>'''

def page(fn, title, desc, active, body, over_dark=False):
    html = head(title, desc, active, over_dark) + "\n" + body + "\n" + foot()
    (ROOT / fn).write_text(html)
    return len(html.encode())

def hero_ctas(light=False):
    p = "btn--primary" if not light else "btn--light"
    a = "btn--apply" if not light else "btn--lightghost"
    cl = "calllink" + (" on-dark" if light else "")
    return f'''<div class="hero-ctas">
        <a href="{C['cal']}" class="btn {p}">Schedule a consultation <span class="ar">&rarr;</span></a>
        <a href="{C['apply']}" class="btn {a}">Apply now</a>
        <a href="tel:{C['tel']}" class="{cl}">Call {C['phone']}</a>
      </div>'''

# =====================================================================
# HOME
# =====================================================================
home = f'''
<section class="hero" data-hero>
  <div class="wrap hero-grid">
    <div class="reveal">
      <div class="label"><span class="n">01</span> &nbsp;Senior Mortgage Advisor — Santa Barbara</div>
      <h1 class="display">Calm, strategic mortgage guidance for California buyers and referral partners.</h1>
      <p class="lead">Helping homebuyers, homeowners, investors, and real estate partners move from first conversation to closing with clarity, confidence, and personal attention.</p>
      {hero_ctas()}
    </div>
    <div class="hero-figure reveal">
      <div class="ph"><img src="assets/img/portrait-hero.jpg" alt="{C['name']}, {C['title']}"></div>
      <div class="cred-card">
        <div class="cc-top"><span class="cc-dot"></span><span>Verified Advisor</span></div>
        <div class="cc-nm">{C['name']}</div>
        <div class="cc-ti">{C['title']} · {C['company']}</div>
        <div class="cc-row">
          <div>NMLS<b>#{C['nmls']}</b></div>
          <div>Licensed<b>California</b></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="proof-sec">
  <div class="wrap">
    <div class="proof reveal">
      <div class="pcell"><div class="pi">Experience</div><div class="ps">15+ Years of Mortgage Guidance</div></div>
      <div class="pcell"><div class="pi">Specialization</div><div class="ps">California Purchase, Refinance &amp; Jumbo Strategy</div></div>
      <div class="pcell"><div class="pi">Approach</div><div class="ps">Built for Borrowers, Investors &amp; Referral Partners</div></div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="wrap split">
    <div class="split-fig reveal"><div class="ph"><img src="assets/img/portrait-about.jpg" alt="{C['name']}"></div></div>
    <div class="split-body reveal">
      <div class="label"><span class="n">02</span> &nbsp;About</div>
      <h2 class="h2">A calm, informed partner through one of life's largest decisions.</h2>
      <p>For more than fifteen years, {C['name']} has guided buyers and investors across the Central Coast through financing built around their goals — explained in plain language, with the details handled before they become problems.</p>
      <p class="serif-it" style="font-size:1.2rem;color:var(--ink)">"My job is to make a complex decision feel clear — and then move quickly once it is."</p>
      <div style="margin-top:26px"><a href="about.html" class="txtlink"><span class="u">More about Daniel</span> &rarr;</a></div>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="shead reveal">
      <div class="label"><span class="n">03</span> &nbsp;Strategy</div>
      <div>
        <h2 class="h2">Jumbo &amp; Coastal Market Strategy</h2>
        <p class="sh-lead">High-value purchases require more than a rate quote. Daniel helps buyers, investors, and referral partners think through structure, timing, documentation, and lender fit before the pressure of a transaction begins.</p>
      </div>
    </div>
    <div class="cards c3 reveal">
      <div class="card"><span class="ci">i.</span><h3>Jumbo purchase planning</h3><p>Structure, reserves, and timing mapped out before you write an offer on a high-value coastal home.</p></div>
      <div class="card"><span class="ci">ii.</span><h3>Self-employed &amp; complex-income guidance</h3><p>Business and complex income read accurately the first time — so strong borrowers aren't penalized for how they earn.</p></div>
      <div class="card"><span class="ci">iii.</span><h3>Realtor-ready pre-approval strategy</h3><p>Pre-approvals your agent can stand behind and present with confidence in a competitive market.</p></div>
    </div>
  </div>
</section>

<section class="section surface-soft">
  <div class="wrap">
    <div class="shead reveal">
      <div class="label"><span class="n">04</span> &nbsp;Loan Programs</div>
      <div>
        <h2 class="h2">Financing matched to the borrower, not the other way around.</h2>
        <p class="sh-lead">From first purchases to jumbo financing and self-employed solutions — structured around your numbers and your timeline.</p>
      </div>
    </div>
    <div class="cards c3 reveal">
      <div class="card"><span class="ci">i.</span><h3>Purchase &amp; Jumbo</h3><p>Conventional and jumbo financing for primary, second, and high-value coastal homes, structured with discretion.</p></div>
      <div class="card"><span class="ci">ii.</span><h3>FHA &amp; VA</h3><p>Lower-down-payment and zero-down paths for first-time buyers, veterans, and eligible service members.</p></div>
      <div class="card"><span class="ci">iii.</span><h3>Investment &amp; Self-Employed</h3><p>Cash-flow and business-income strategies for investors and entrepreneurs whose income deserves a closer read.</p></div>
    </div>
    <div class="reveal" style="margin-top:44px"><a href="loan-programs.html" class="btn btn--ghost">View all programs <span class="ar">&rarr;</span></a></div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="shead reveal">
      <div class="label"><span class="n">05</span> &nbsp;The Process</div>
      <div><h2 class="h2">Four steps, fully guided.</h2></div>
    </div>
    <div class="proc reveal">
      <div class="step"><span class="pn">01</span><h3>Discovery Call</h3><p>A short conversation to understand your goals, timeline, and the numbers that shape your options.</p></div>
      <div class="step"><span class="pn">02</span><h3>Pre-Approval &amp; Strategy</h3><p>A fully prepared pre-approval and a financing plan you can act on in a competitive market.</p></div>
      <div class="step"><span class="pn">03</span><h3>Application &amp; Docs</h3><p>A streamlined application with a simple checklist and proactive updates at every milestone.</p></div>
      <div class="step"><span class="pn">04</span><h3>Closing</h3><p>On-time coordination with your agent and escrow so signing day is smooth and certain.</p></div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="wrap">
    <div class="shead center reveal">
      <div class="label center"><span class="n">06</span> &nbsp;Client Reviews</div>
      <h2 class="h2">Trusted across the Central Coast.</h2>
    </div>
    <div class="cards c3">
      <div class="quote reveal"><span class="qm">&ldquo;</span><blockquote>Daniel helped us understand our options before we made an offer, gave us a clear pre-approval strategy, and kept us calm all the way through closing.</blockquote><div class="qrule"></div><div class="qa">Sarah M.</div><div class="qr">First-Time Buyer · Santa Barbara</div></div>
      <div class="quote reveal"><span class="qm">&ldquo;</span><blockquote>We needed a jumbo loan with a few moving parts, and Daniel made the process feel organized from the first call. His communication gave everyone confidence.</blockquote><div class="qrule"></div><div class="qa">Jason &amp; Nicole T.</div><div class="qr">Jumbo Purchase · Montecito</div></div>
      <div class="quote reveal"><span class="qm">&ldquo;</span><blockquote>As an agent, I value lending partners who communicate early and protect the client experience. Daniel is the kind of advisor I feel comfortable introducing to my buyers.</blockquote><div class="qrule"></div><div class="qa">Michael R.</div><div class="qr">Realtor Partner · Ventura County</div></div>
    </div>
  </div>
</section>

<section class="band">
  <div class="wrap band-split">
    <div class="reveal">
      <div class="label on-dark"><span class="n">07</span> &nbsp;For Realtors</div>
      <h2 class="h2" style="margin-top:20px">A lending partner your clients can trust.</h2>
      <p style="margin-top:18px;max-width:44ch">Reliable communication, strategic pre-approvals, and on-time closings that protect the relationship you've built.</p>
      <div style="margin-top:32px"><a href="realtor-partners.html" class="btn btn--light">Partner with Daniel <span class="ar">&rarr;</span></a></div>
    </div>
    <div class="aside-card reveal">
      <div class="ab">On time.</div><div class="ak">Closings coordinated to your date</div><hr>
      <div class="ab">Same day.</div><div class="ak">Responses to you and your clients</div>
    </div>
  </div>
</section>

<section class="final">
  <div class="bg" style="background-image:url('assets/img/home.jpg')"></div>
  <div class="wrap"><div class="reveal">
    <div class="label center on-dark"><span class="n">08</span> &nbsp;Let's Begin</div>
    <h2>Ready to take the next step?</h2>
    <p>Whether you're months away or making an offer this week, a short conversation is the best place to start.</p>
    <div class="ctas">
      <a href="{C['cal']}" class="btn btn--light">Schedule a consultation <span class="ar">&rarr;</span></a>
      <a href="{C['prequal']}" class="btn btn--lightghost">Get pre-qualified</a>
      <a href="tel:{C['tel']}" class="btn btn--lightghost">Call {C['phone']}</a>
    </div>
  </div></div>
</section>
'''

# =====================================================================
# ABOUT
# =====================================================================
about = f'''
<section class="hero" data-hero>
  <div class="wrap hero-grid">
    <div class="reveal">
      <div class="label"><span class="n">01</span> &nbsp;About {C['name']}</div>
      <h1 class="display">Financing should feel like guidance, not a transaction.</h1>
      <p class="lead">Daniel built his practice on a simple idea: explain everything clearly, move quickly, and treat every client's purchase as if it were his own.</p>
      <div class="hero-ctas">
        <a href="{C['cal']}" class="btn btn--primary">Schedule a consultation <span class="ar">&rarr;</span></a>
        <a href="tel:{C['tel']}" class="calllink">Call {C['phone']}</a>
      </div>
    </div>
    <div class="hero-figure reveal">
      <div class="ph"><img src="assets/img/portrait-about.jpg" alt="{C['name']}, {C['title']}"></div>
      <div class="cred-card">
        <div class="cc-top"><span class="cc-dot"></span><span>Senior Advisor</span></div>
        <div class="cc-nm">{C['name']}</div>
        <div class="cc-ti">{C['title']}</div>
        <div class="cc-row"><div>Experience<b>15+ Years</b></div><div>Focus<b>Jumbo &amp; Purchase</b></div></div>
      </div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="wrap split rev">
    <div class="split-body reveal">
      <div class="label"><span class="n">02</span> &nbsp;The Bio</div>
      <h2 class="h2">Fifteen years on the Central Coast.</h2>
      <p>{C['name']} has spent more than fifteen years helping Californians finance the places they live, invest in, and build their lives around. He began his career drawn to the part of the process most advisors rush past — the conversation where a buyer finally understands their options and feels in control of the decision.</p>
      <p>Today, as {C['title']} at {C['company']}, he works with first-time buyers, growing families, seasoned investors, and self-employed borrowers whose income deserves a closer read. His reputation is built on responsiveness and candor: clients hear back quickly, get straight answers, and always know what happens next.</p>
      <p>When a loan is the right move, Daniel structures it precisely. When it isn't, he says so. That honesty is why so much of his business comes from past clients and the agents who trust him with their own.</p>
    </div>
    <div class="split-fig reveal"><div class="ph"><img src="assets/img/office.jpg" alt="{C['company']} office, Santa Barbara"></div></div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="shead reveal">
      <div class="label"><span class="n">03</span> &nbsp;Values</div>
      <div><h2 class="h2">The principles behind every file.</h2></div>
    </div>
    <div class="cards c3 reveal">
      <div class="card"><span class="ci">i.</span><h3>Clarity first</h3><p>Every rate, cost, and tradeoff explained in plain language before you commit to anything.</p></div>
      <div class="card"><span class="ci">ii.</span><h3>Responsiveness</h3><p>Calls and messages returned the same day. You are never left wondering where things stand.</p></div>
      <div class="card"><span class="ci">iii.</span><h3>Candor</h3><p>Honest counsel — including when the right advice is to wait, restructure, or walk away.</p></div>
      <div class="card"><span class="ci">iv.</span><h3>Precision</h3><p>Files structured correctly the first time, so underwriting moves and closings hold their dates.</p></div>
      <div class="card"><span class="ci">v.</span><h3>Discretion</h3><p>Sensitive financial details handled with the privacy and care they deserve.</p></div>
      <div class="card"><span class="ci">vi.</span><h3>Partnership</h3><p>A relationship that continues well past closing — for the next move and the referral after that.</p></div>
    </div>
  </div>
</section>

<section class="section surface-soft">
  <div class="wrap">
    <div class="shead reveal">
      <div class="label"><span class="n">04</span> &nbsp;Local Expertise</div>
      <div><h2 class="h2">Deeply rooted on the coast.</h2></div>
    </div>
    <div class="cards c3 reveal">
      <div class="card"><h3>Santa Barbara</h3><p>From State Street condos to Riviera estates — fluent in the city's valuations and timelines.</p></div>
      <div class="card"><h3>Montecito</h3><p>Jumbo and high-value financing handled with the discretion the market expects.</p></div>
      <div class="card"><h3>Goleta</h3><p>First-time and move-up buyers navigating one of the area's most competitive segments.</p></div>
      <div class="card"><h3>Ventura</h3><p>Coastal and inland purchases, refinances, and investment properties across the county.</p></div>
      <div class="card"><h3>Westlake Village</h3><p>Move-up buyers and investors at the Ventura–LA County line, served end to end.</p></div>
      <div class="card"><h3>Surrounding markets</h3><p>Trusted guidance throughout the surrounding California communities Daniel calls home.</p></div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="wrap">
    <div class="shead center reveal">
      <div class="label center"><span class="n">05</span> &nbsp;What Clients Can Expect</div>
      <h2 class="h2">The reasons clients return — and refer.</h2>
    </div>
    <div class="cards c2 reveal" style="max-width:920px;margin:0 auto">
      <div class="card"><h3>You always know the plan</h3><p>A clear strategy from day one and proactive updates at every milestone, so nothing catches you off guard.</p></div>
      <div class="card"><h3>Your time is respected</h3><p>Fast pre-approvals, a simple document checklist, and a process that keeps moving without chasing.</p></div>
      <div class="card"><h3>The numbers are honest</h3><p>Transparent figures up front and a frank read on whether a loan truly serves your goals.</p></div>
      <div class="card"><h3>The relationship lasts</h3><p>Most of Daniel's business comes from clients and agents who've worked with him before.</p></div>
    </div>
  </div>
</section>

<section class="band deepest">
  <div class="wrap">
    <div class="midcta reveal">
      <div class="label center on-dark"><span class="n">06</span> &nbsp;Let's Talk</div>
      <h2 class="h2">Start with a conversation.</h2>
      <p>No pressure and no obligation — just clear answers about your options.</p>
      <div class="ctas"><a href="{C['cal']}" class="btn btn--light">Schedule a consultation <span class="ar">&rarr;</span></a><a href="{C['apply']}" class="btn btn--lightghost">Apply now</a></div>
    </div>
  </div>
</section>
'''

# =====================================================================
# LOAN PROGRAMS
# =====================================================================
programs_data = [
    ("01","Conventional Loans","Competitive fixed and adjustable-rate financing for primary residences and second homes, with flexible terms for well-qualified borrowers.","Buyers with steady income and solid credit seeking the broadest range of terms."),
    ("02","FHA Loans","Government-backed financing with flexible qualifying and lower down-payment requirements — a practical entry point into homeownership.","First-time buyers and those building credit or with limited down-payment funds."),
    ("03","VA Loans","Zero-down financing with favorable terms and no monthly mortgage insurance, earned through military service.","Veterans, active-duty service members, and eligible surviving spouses."),
    ("04","Jumbo Loans","Financing above conforming limits for high-value Santa Barbara and Montecito properties, structured with discretion.","Buyers of luxury and high-priced coastal homes needing larger loan amounts."),
    ("05","Refinance","Lower a rate, shorten a term, or access equity — always preceded by a clear, honest cost-benefit walkthrough.","Homeowners looking to reduce payments, change terms, or tap equity wisely."),
    ("06","First-Time Homebuyer Programs","Down-payment options paired with step-by-step guidance designed to make the first purchase feel manageable.","Buyers purchasing their first home who want a patient, educational process."),
    ("07","Investment Property Loans","Purchase and portfolio strategies built around cash flow, reserves, and long-term returns.","Investors growing a rental portfolio or financing additional properties."),
    ("08","Self-Employed Borrower Solutions","Financing that reads real business income accurately, structured around the way entrepreneurs actually earn.","Business owners, 1099 earners, and self-employed borrowers with complex income."),
]
prog_rows = "\n".join(f'''      <div class="prow reveal">
        <div class="pn">{n}</div>
        <div class="pt">{t}</div>
        <div class="pd"><p>{d}</p><div class="good"><b>Good for</b>{g}</div></div>
        <div class="pc"><a href="{C['cal']}" class="btn btn--ghost">Discuss options <span class="ar">&rarr;</span></a></div>
      </div>''' for n,t,d,g in programs_data)

faqs = [
    ("How much do I need for a down payment?","It depends on the program. Some loans allow as little as 3% down, VA and certain programs allow zero down for eligible borrowers, and larger down payments can improve your terms. We'll map the options to your specific situation on the first call."),
    ("What credit score do I need?","Many programs work with scores in the low-to-mid 600s, and some go lower. Score is only one factor — income, assets, and debt all matter. If your score isn't where you'd like, Daniel will give you a clear, honest plan to get there."),
    ("How long does pre-approval take?","Often the same day once Daniel has your documents. A complete pre-approval gives you a firm number and the credibility to make strong offers in a competitive market."),
    ("Can I qualify if I'm self-employed?","Yes. Self-employed borrowers qualify all the time — it simply requires structuring the file correctly. Daniel specializes in reading business income accurately and matching it to the right program."),
    ("What's the difference between pre-qualification and pre-approval?","Pre-qualification is a quick estimate based on information you share. Pre-approval is a verified review of your credit, income, and assets — a far stronger position when you're ready to make an offer."),
]
faq_items = "\n".join(f'''      <div class="faq-i"><button class="faq-q">{q} <span class="ic"></span></button><div class="faq-a"><p>{a}</p></div></div>''' for q,a in faqs)

programs = f'''
<section class="hero-band" data-hero>
  <div class="bg" style="background-image:url('assets/img/home.jpg')"></div>
  <div class="wrap reveal">
    <div class="label on-dark"><span class="n">01</span> &nbsp;Loan Programs</div>
    <h1 class="display">The right structure for every borrower.</h1>
    <p class="lead">From first-time purchases to jumbo financing and self-employed solutions — matched to your goals, your timeline, and your numbers.</p>
    {hero_ctas(light=True)}
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="prog">
{prog_rows}
    </div>
  </div>
</section>

<section class="section surface-soft">
  <div class="wrap">
    <div class="shead center reveal">
      <div class="label center"><span class="n">02</span> &nbsp;Mortgage FAQ</div>
      <h2 class="h2">Answers before you ask.</h2>
    </div>
    <div class="faq reveal">
{faq_items}
    </div>
  </div>
</section>

<section class="band deepest">
  <div class="wrap">
    <div class="midcta reveal">
      <div class="label center on-dark"><span class="n">03</span> &nbsp;Not sure which fits?</div>
      <h2 class="h2">Let's find the right program together.</h2>
      <p>A short call is the fastest way to know your real options and what they'll cost.</p>
      <div class="ctas"><a href="{C['cal']}" class="btn btn--light">Schedule a consultation <span class="ar">&rarr;</span></a><a href="{C['apply']}" class="btn btn--lightghost">Apply now</a><a href="{C['prequal']}" class="btn btn--lightghost">Get pre-qualified</a></div>
    </div>
  </div>
</section>
'''

# =====================================================================
# REALTOR PARTNERS
# =====================================================================
realtors = f'''
<section class="hero-band" data-hero>
  <div class="bg" style="background-image:url('assets/img/meeting.jpg')"></div>
  <div class="wrap reveal">
    <div class="label on-dark"><span class="n">01</span> &nbsp;For Realtors &amp; Referral Partners</div>
    <h1 class="display">A lending partner your clients can trust from first call to closing.</h1>
    <p class="lead">When you send a buyer to Daniel, you're handing them to someone who protects your relationship as carefully as you built it.</p>
    <div class="hero-ctas">
      <a href="{C['cal']}" class="btn btn--light">Let's partner <span class="ar">&rarr;</span></a>
      <a href="tel:{C['tel']}" class="calllink on-dark">Call {C['phone']}</a>
    </div>
  </div>
</section>

<section class="section">
  <div class="wrap">
    <div class="shead reveal">
      <div class="label"><span class="n">02</span> &nbsp;Why Agents Partner</div>
      <div>
        <h2 class="h2">Your reputation is on the line with every referral.</h2>
        <p class="sh-lead">Daniel treats it that way — protecting your client relationship from the first call through the closing table.</p>
      </div>
    </div>
    <div class="cards c3 reveal">
      <div class="card"><span class="ci">i.</span><h3>Communication promise</h3><p>Same-day responses to you and your clients, and a heads-up the moment anything needs attention — no silence, no surprises.</p></div>
      <div class="card"><span class="ci">ii.</span><h3>Strategic pre-approvals</h3><p>Fully prepared, accurate pre-approvals that make your clients' offers stronger and help them win competitive situations.</p></div>
      <div class="card"><span class="ci">iii.</span><h3>Smooth closing support</h3><p>Files structured correctly the first time and timelines coordinated with escrow, so closing dates hold.</p></div>
      <div class="card"><span class="ci">iv.</span><h3>Co-branded experience</h3><p>Co-branded pre-approval letters, flyers, and open-house materials that keep your name front and center.</p></div>
      <div class="card"><span class="ci">v.</span><h3>Shared-client care</h3><p>Your clients are treated like his own — the professionalism reflects back onto you.</p></div>
      <div class="card"><span class="ci">vi.</span><h3>A true partnership</h3><p>A dependable lending relationship you can build a referral business around, deal after deal.</p></div>
    </div>
  </div>
</section>

<section class="band">
  <div class="wrap band-split">
    <div class="reveal">
      <div class="label on-dark"><span class="n">03</span> &nbsp;The Partnership Standard</div>
      <h2 class="h2" style="margin-top:20px">What you can count on, every transaction.</h2>
      <ul class="band-list">
        <li>A pre-approval you can put real weight behind</li>
        <li>Proactive updates at every milestone — to you and the client</li>
        <li>Closings coordinated to your contract dates</li>
        <li>Co-branded materials that keep your brand visible</li>
        <li>Discretion and professionalism with shared clients</li>
      </ul>
      <a href="{C['cal']}" class="btn btn--light">Let's partner <span class="ar">&rarr;</span></a>
    </div>
    <div class="aside-card reveal">
      <div class="ab">On time.</div><div class="ak">Closings held to your date</div><hr>
      <div class="ab">Same day.</div><div class="ak">Responses, every time</div><hr>
      <div class="ab">Zero drama.</div><div class="ak">A process built to protect your name</div>
    </div>
  </div>
</section>

<section class="section surface">
  <div class="wrap">
    <div class="shead center reveal">
      <div class="label center"><span class="n">04</span> &nbsp;Partner Testimonial</div>
      <h2 class="h2">From an agent who refers.</h2>
    </div>
    <div class="reveal" style="max-width:820px;margin:0 auto">
      <div class="quote feature">
        <span class="qm">&ldquo;</span>
        <blockquote>I send Daniel my most important clients without a second thought. He communicates better than any lender I've worked with, and my closings simply happen on time. He makes me look good — and that's everything in this business.</blockquote>
        <div class="qrule" style="margin-left:auto;margin-right:auto"></div>
        <div class="qa">Lauren P.</div>
        <div class="qr">Real Estate Agent · Santa Barbara</div>
      </div>
    </div>
  </div>
</section>

<section class="final">
  <div class="bg" style="background-image:url('assets/img/home.jpg')"></div>
  <div class="wrap"><div class="reveal">
    <div class="label center on-dark"><span class="n">05</span> &nbsp;Let's Partner</div>
    <h2>Build a referral relationship that lasts.</h2>
    <p>Let's grab fifteen minutes and talk about how we can serve your clients together.</p>
    <div class="ctas">
      <a href="{C['cal']}" class="btn btn--light">Schedule a partner call <span class="ar">&rarr;</span></a>
      <a href="mailto:{C['email']}" class="btn btn--lightghost">Email Daniel</a>
      <a href="tel:{C['tel']}" class="btn btn--lightghost">Call {C['phone']}</a>
    </div>
  </div></div>
</section>
'''

# =====================================================================
# LEGAL PAGES (privacy / terms)
# =====================================================================
def legal_page(fn, title, label_no, heading, intro, sections):
    secs = ""
    for i,(h,paras) in enumerate(sections, 1):
        body = "".join(f"<p>{p}</p>" for p in paras)
        secs += f'''<section class="legal-sec reveal"><div class="ls-no">{i:02d}</div><div class="ls-body"><h2>{h}</h2>{body}</div></section>\n'''
    body = f'''
<section class="legal-hero">
  <div class="wrap">
    <div class="label"><span class="n">{label_no}</span> &nbsp;Legal</div>
    <h1 class="legal-title">{heading}</h1>
    <p class="legal-meta">Last updated: January 2026</p>
    <p class="legal-intro">{intro}</p>
  </div>
</section>
<section class="section s-tight">
  <div class="wrap legal-wrap">
    {secs}
    <p class="legal-note">This page is template language provided for demonstration. Replace it with your firm's reviewed policy before launch.</p>
  </div>
</section>
'''
    html = head(title, f"{heading} — {C['name']}, {C['company']}.", None, False) + "\n" + body + "\n" + foot()
    (ROOT / fn).write_text(html)
    return len(html.encode())

privacy_sections = [
    ("Information We Collect", [
        "We collect information you choose to provide and limited technical information sent automatically by your browser. This may include your name, email address, phone number, and any details you share when you contact us or request a consultation.",
        "We collect only what is reasonably necessary to respond to your inquiry and provide mortgage guidance."]),
    ("Contact Form &amp; Inquiry Data", [
        "When you submit a contact form, request a consultation, or email us, the information you provide is used to respond to your request and to follow up about your financing needs. We do not sell this information."]),
    ("Analytics &amp; Cookies", [
        "This website may use cookies and basic analytics to understand how visitors use the site and to improve the experience. You can disable cookies in your browser settings. <em>[Placeholder — describe your specific analytics provider and cookie practices here.]</em>"]),
    ("Third-Party Links", [
        "Our site links to third-party services such as scheduling (Calendly) and online application portals. When you follow these links, you leave our website and are subject to the privacy practices of those providers. We encourage you to review their policies."]),
    ("Contact", [
        f"For questions about this policy, contact {C['name']} at {C['email']} or {C['phone']}. <em>[Placeholder — add your full business contact and mailing address.]</em>"]),
]

terms_sections = [
    ("Informational Use Only", [
        "The content on this website is provided for general informational purposes only. It does not constitute financial, legal, or tax advice, and should not be relied upon as a substitute for a personal consultation."]),
    ("Not a Loan Approval or Commitment to Lend", [
        "Nothing on this website constitutes an approval, pre-approval, or commitment to lend. All loans are subject to credit approval, underwriting, and program guidelines. Rates, terms, and program availability are subject to change without notice."]),
    ("External Links", [
        "This website may contain links to third-party websites and tools, including scheduling and application portals. We are not responsible for the content, accuracy, or practices of any third-party site."]),
    ("Intellectual Property", [
        "The design, text, and graphics on this website are provided for the use of the business named herein. <em>[Placeholder — add your ownership, trademark, and usage terms here.]</em>"]),
    ("Contact", [
        f"For questions about these terms, contact {C['name']} at {C['email']} or {C['phone']}. <em>[Placeholder — add your full business contact and mailing address.]</em>"]),
]

# ---------------- write ----------------
sizes = {}
sizes["index.html"] = page("index.html","Daniel Harper · Senior Mortgage Advisor | Coastal Bridge Home Loans","Calm, strategic mortgage guidance for California buyers and referral partners. Daniel Harper, Senior Mortgage Advisor at Coastal Bridge Home Loans.","home",home)
sizes["about.html"] = page("about.html","About Daniel Harper | Coastal Bridge Home Loans","Fifteen years of mortgage guidance across Santa Barbara, Montecito, Goleta, Ventura, and Westlake Village.","about",about)
sizes["loan-programs.html"] = page("loan-programs.html","Loan Programs | Daniel Harper · Coastal Bridge Home Loans","Conventional, FHA, VA, jumbo, refinance, first-time, investment, and self-employed loan programs.","programs",programs)
sizes["realtor-partners.html"] = page("realtor-partners.html","Realtor Partners | Daniel Harper · Coastal Bridge Home Loans","A lending partner real estate agents trust from first call to closing.","realtors",realtors)
sizes["privacy.html"] = legal_page("privacy.html","Privacy Policy | Coastal Bridge Home Loans","09","Privacy Policy","This Privacy Policy explains what information this website collects, how it is used, and the choices available to you.",privacy_sections)
sizes["terms.html"] = legal_page("terms.html","Terms of Use | Coastal Bridge Home Loans","09","Terms of Use","These Terms of Use govern your use of this website and the information provided on it.",terms_sections)

for k,v in sizes.items():
    print(f"{k:24} {v/1024:6.1f} KB  unreplaced:{open(ROOT/k).read().count('{{')}")
print("done")
