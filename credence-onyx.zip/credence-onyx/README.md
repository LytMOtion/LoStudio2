# credencesites.com — Template 2: "Onyx" (Charcoal Luxury)

A premium, static personal-brand website for high-end loan officers, senior mortgage
advisors, branch managers, and jumbo specialists. No frameworks, no build step
required. Pure HTML, CSS, and a single vanilla-JS file. Vercel-ready.

---

## File structure

```
/
├─ index.html              Home
├─ about.html              About
├─ loan-programs.html      Loan Programs (+ FAQ)
├─ realtor-partners.html   Realtor Partners
├─ privacy.html            Privacy Policy
├─ terms.html              Terms of Use
├─ assets/
│  ├─ css/styles.css       All styling. Tokens at the very top (:root).
│  ├─ js/main.js           Header, mobile menu, FAQ, reveals, sticky CTA bar.
│  └─ img/                 Replace these files, keep the same names.
│     ├─ portrait-hero.jpg     (~560×720, portrait)
│     ├─ portrait-about.jpg    (~540×720, portrait)
│     ├─ office.jpg            (~1400 wide, landscape)
│     ├─ home.jpg              (~1600 wide, landscape — hero/CTA backgrounds)
│     └─ meeting.jpg           (~1400 wide, landscape)
└─ build.py                OPTIONAL. Regenerates the 4 HTML files from one data block.
```

## Deploy (Vercel)

1. Push this folder to a Git repo (or drag-and-drop the folder into Vercel).
2. No framework, no build command, no output dir — it's a static site.
3. **Important:** `index.html` and the `assets/` folder must sit at the **deploy root**
   together. If you push the project inside a subfolder, set Vercel →
   Project → Settings → **Root Directory** to that subfolder, or the CSS/images 404.

### Deploy-safe `dist/` (zero external files)
The included `dist/` folder contains the same pages with all CSS, JS, and images
**inlined** — nothing to 404 regardless of how it's hosted. If a modular deploy ever
shows up unstyled, deploy `dist/` instead. Regenerate it any time with
`python3 build_inline.py`.

---

## Rebrand in 3 places

### 1. Client data — find & replace in the four `.html` files
Replace the demo values with the client's. Every value appears as plain text:

| Find | Replace with |
|------|--------------|
| `Daniel Harper` | Client name |
| `Senior Mortgage Advisor` | Client title |
| `Coastal Bridge Home Loans` | Company |
| `1845627` | Personal NMLS |
| `2279431` | Company NMLS |
| `(805) 555-1847` | Phone (display) |
| `+18055551847` | Phone (tel: link — digits only, with +1) |
| `daniel@coastalbridgehl.com` | Email |
| `1450 State Street, Suite 210` | Address line 1 |
| `Santa Barbara, CA 93101` | Address line 2 |
| `https://calendly.com/danielharper/consultation` | Scheduling link |
| `https://apply.coastalbridgehl.com/danielharper` | Apply link |
| `https://prequal.coastalbridgehl.com/danielharper` | Pre-qualify link |
| `https://instagram.com/danielharpermortgage` | Instagram |
| `https://linkedin.com/in/danielharpermortgage` | LinkedIn |

Also swap the bio, testimonials, service-area cities, and the `#` placeholders on
Privacy Policy / Terms of Use links when those pages exist.

### 2. Colors & type — edit the tokens at the top of `assets/css/styles.css`
```
:root{
  --bg, --surface, --surface-soft, --ink, --ink-soft, --muted,
  --line, --line-strong, --navy, --navy-soft, --champagne, --dark,
  --serif, --sans
}
```
Onyx is the dark theme: charcoal palette, champagne accent, Cormorant Garamond display. Change `--champagne` and the `:root` tones to re-skin. To change fonts, edit the
Google Fonts `<link>` in each HTML `<head>` and update `--serif` / `--sans`.

### 3. Images — replace files in `assets/img/`, keep the filenames
Use natural-light, editorial real-estate / finance photography. Portraits should be
roughly 3:4. The code applies a subtle desaturation for cohesion.

---

## Optional: regenerate with build.py
For agencies producing many client sites: edit the single `C = dict(...)` block at
the top of `build.py`, then run `python3 build.py`. It rewrites all four HTML files
with consistent header/footer/mobile-bar. (Editing the HTML directly is perfectly
fine too — this is just a convenience.)

---

## Compliance notes
- Update the **NMLS Consumer Access** link if a direct/branded URL is preferred.
- **Equal Housing Lender** text and the loan disclaimer are in the footer of every page.
- Wire **Privacy Policy** and **Terms of Use** (`href="#"`) to real pages before launch.
