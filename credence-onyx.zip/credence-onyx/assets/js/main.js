/* ============================================================
   Credence — "Editorial Luxury"  ·  main.js
   No dependencies. Plain vanilla JS.
   ============================================================ */
(function () {
  "use strict";

  /* Sticky header: solidify on scroll */
  var head = document.querySelector(".head");
  function onScroll() {
    if (window.scrollY > 40) head.classList.add("scrolled");
    else head.classList.remove("scrolled");
  }
  if (head) {
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* Mobile menu */
  var burger = document.querySelector(".burger");
  var nav = document.querySelector(".nav");
  if (burger && nav) {
    burger.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      document.body.classList.toggle("menu-open", open);
      burger.setAttribute("aria-expanded", open);
    });
    nav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        nav.classList.remove("open");
        document.body.classList.remove("menu-open");
        burger.setAttribute("aria-expanded", false);
      });
    });
  }

  /* FAQ accordion */
  document.querySelectorAll(".faq-i").forEach(function (item) {
    var q = item.querySelector(".faq-q");
    var a = item.querySelector(".faq-a");
    if (!q || !a) return;
    q.addEventListener("click", function () {
      var open = item.classList.contains("open");
      document.querySelectorAll(".faq-i").forEach(function (o) {
        o.classList.remove("open");
        var oa = o.querySelector(".faq-a");
        if (oa) oa.style.maxHeight = null;
      });
      if (!open) {
        item.classList.add("open");
        a.style.maxHeight = a.scrollHeight + "px";
      }
    });
  });

  /* Scroll reveal */
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!reduce && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          io.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    document.querySelectorAll(".reveal").forEach(function (el) { io.observe(el); });
  } else {
    document.querySelectorAll(".reveal").forEach(function (el) { el.classList.add("in"); });
  }

  /* Mobile sticky CTA bar: show after hero scrolls away, hide over footer */
  var mbar = document.querySelector(".mbar");
  var hero = document.querySelector("[data-hero]");
  var foot = document.querySelector(".foot");
  if (mbar) {
    document.body.classList.add("has-mbar");
    var pastHero = false, atFoot = false;
    function sync() { mbar.classList.toggle("show", pastHero && !atFoot); }
    if ("IntersectionObserver" in window) {
      if (hero) {
        new IntersectionObserver(function (es) {
          pastHero = !es[0].isIntersecting; sync();
        }, { rootMargin: "-120px 0px 0px 0px" }).observe(hero);
      } else { pastHero = true; }
      if (foot) {
        new IntersectionObserver(function (es) {
          atFoot = es[0].isIntersecting; sync();
        }, { rootMargin: "0px 0px -20% 0px" }).observe(foot);
      }
      sync();
    } else {
      mbar.classList.add("show");
    }
  }
})();
