"""Compile the modular pages into fully self-contained pages in dist/.
CSS, JS, and images are inlined so the output has zero external dependencies.
Run after build.py:  python3 build_inline.py
"""
import base64, pathlib, re

ROOT = pathlib.Path(__file__).parent
DIST = ROOT / "dist"
DIST.mkdir(exist_ok=True)

css = (ROOT / "assets/css/styles.css").read_text()
js  = (ROOT / "assets/js/main.js").read_text()

imgs = {}
for p in (ROOT / "assets/img").glob("*.jpg"):
    b64 = base64.b64encode(p.read_bytes()).decode()
    imgs[f"assets/img/{p.name}"] = f"data:image/jpeg;base64,{b64}"

pages = ["index.html", "about.html", "loan-programs.html",
         "realtor-partners.html", "privacy.html", "terms.html"]

for fn in pages:
    html = (ROOT / fn).read_text()
    html = html.replace('<link rel="stylesheet" href="assets/css/styles.css">', f"<style>\n{css}\n</style>")
    html = html.replace('<script src="assets/js/main.js"></script>', f"<script>\n{js}\n</script>")
    for path, uri in imgs.items():
        html = html.replace(path, uri)
    leftover = re.findall(r"assets/(?:img|css|js)/[^'\"\) ]+", html)
    (DIST / fn).write_text(html)
    print(f"dist/{fn:24} {len(html.encode())/1024:6.0f} KB  leftover={len(leftover)}")
print("dist build complete")
